import { Injectable } from '@angular/core';
import { BackendService } from './backend.service';
import { User } from './models/user.model';
import { UsersService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  accessToken: any;


  constructor(private backend: BackendService) { }

  public loggedUser?: User;
  public get isLoggedIn(): boolean {
    return !!this.loggedUser;
  }

  createUser(name: string, email: string, password: string): void {
    this.backend.createUser(name, email, password).subscribe(
      (ur: UsersService) => {
        this.loggedUser = ur.user;
        this.accessToken = ur.accessToken;
      }
    )
  }

  login(email: string, password: string): void {}
}
