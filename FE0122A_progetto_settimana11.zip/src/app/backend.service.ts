import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class BackendService {

  constructor( private httpClient: HttpClient) { }

  private baseUrl: string = 'http://localhost:4201/api/';



  createUser(name: string, email: string, password: string): Observable<any> {
    const newUser:   User = {
      name,
      email,
      password,
      id: 0
    }

    return this.httpClient.post<User>(
      this.baseUrl + 'users',
      newUser,
      )
  }




  login() {}
}



